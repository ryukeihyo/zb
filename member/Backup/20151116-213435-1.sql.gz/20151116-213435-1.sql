-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : zebai
-- 
-- Part : #1
-- Date : 2015-11-16 21:34:35
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `zb_addon`
-- -----------------------------
DROP TABLE IF EXISTS `zb_addon`;
CREATE TABLE `zb_addon` (
  `id` int(11) unsigned NOT NULL auto_increment COMMENT '主键',
  `name` varchar(32) NOT NULL default '' COMMENT '插件名或标识',
  `title` varchar(32) NOT NULL default '' COMMENT '中文名',
  `description` text NOT NULL COMMENT '插件描述',
  `config` text COMMENT '配置',
  `author` varchar(32) NOT NULL default '' COMMENT '作者',
  `version` varchar(8) NOT NULL default '' COMMENT '版本号',
  `adminlist` tinyint(4) unsigned NOT NULL default '0' COMMENT '是否有后台列表',
  `type` tinyint(4) unsigned NOT NULL default '0' COMMENT '插件类型',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '安装时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '修改时间',
  `sort` tinyint(4) unsigned NOT NULL default '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL default '1' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `zb_addon`
-- -----------------------------
INSERT INTO `zb_addon` VALUES ('1', 'ReturnTop', '返回顶部', '返回顶部', '{\"status\":\"1\",\"theme\":\"rocket\",\"customer\":\"\",\"case\":\"\",\"qq\":\"\",\"weibo\":\"\"}', 'CoreThink', '1.0', '0', '0', '1407681961', '1408602081', '0', '1');
INSERT INTO `zb_addon` VALUES ('2', 'Email', '邮件插件', '实现系统发邮件功能', '{\"status\":\"1\",\"MAIL_SMTP_TYPE\":\"2\",\"MAIL_SMTP_SECURE\":\"0\",\"MAIL_SMTP_PORT\":\"25\",\"MAIL_SMTP_HOST\":\"smtp.qq.com\",\"MAIL_SMTP_USER\":\"\",\"MAIL_SMTP_PASS\":\"\",\"default\":\"[MAILBODY]\"}', 'CoreThink', '1.0', '0', '0', '1428732454', '1428732454', '0', '1');
INSERT INTO `zb_addon` VALUES ('3', 'SyncLogin', '第三方账号登陆', '第三方账号登陆', '{\"type\":[\"Weixin\",\"Qq\",\"Sina\"],\"meta\":\"\",\"WeixinKEY\":\"\",\"WeixinSecret\":\"\",\"QqKEY\":\"\",\"QqSecret\":\"\",\"SinaKEY\":\"\",\"SinaSecret\":\"\",\"RenrenKEY\":\"\",\"RenrenSecret\":\"\"}', 'CoreThink', '1.0', '1', '0', '1428250248', '1428250248', '0', '0');
INSERT INTO `zb_addon` VALUES ('4', 'AdFloat', '图片漂浮广告', '图片漂浮广告', '{\"status\":\"0\",\"url\":\"http:\\/\\/www.corethink.cn\",\"image\":\"\",\"width\":\"100\",\"height\":\"100\",\"speed\":\"10\",\"target\":\"1\"}', 'CoreThink', '1.0', '0', '0', '1408602081', '1408602081', '0', '1');

-- -----------------------------
-- Table structure for `zb_addon_hook`
-- -----------------------------
DROP TABLE IF EXISTS `zb_addon_hook`;
CREATE TABLE `zb_addon_hook` (
  `id` int(10) unsigned NOT NULL auto_increment COMMENT '钩子ID',
  `name` varchar(32) NOT NULL default '' COMMENT '钩子名称',
  `description` text NOT NULL COMMENT '描述',
  `addons` varchar(255) NOT NULL COMMENT '钩子挂载的插件 ''，''分割',
  `type` tinyint(4) unsigned NOT NULL default '1' COMMENT '类型',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL default '1' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='钩子表';

-- -----------------------------
-- Records of `zb_addon_hook`
-- -----------------------------
INSERT INTO `zb_addon_hook` VALUES ('1', 'PageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', 'SyncLogin', '1', '1407681961', '1407681961', '1');
INSERT INTO `zb_addon_hook` VALUES ('2', 'PageFooter', '页面footer钩子，一般用于加载插件CSS文件和代码', 'ReturnTop,AdFloat', '1', '1407681961', '1407681961', '1');
INSERT INTO `zb_addon_hook` VALUES ('3', 'PageSide', '页面侧边栏钩子', '', '1', '1407681961', '1407681961', '1');
INSERT INTO `zb_addon_hook` VALUES ('4', 'DocumentListBefore', '文档列表页面顶部钩子', '', '1', '1407681961', '1407681961', '1');
INSERT INTO `zb_addon_hook` VALUES ('5', 'DocumentListAfter', '文档列表页面底部钩子', '', '1', '1407681961', '1407681961', '1');
INSERT INTO `zb_addon_hook` VALUES ('6', 'DocumentDetailBefore', '文档详情页面顶部钩子', '', '1', '1407681961', '1407681961', '1');
INSERT INTO `zb_addon_hook` VALUES ('7', 'DocumentDetailAfter', '文档详情页面底部钩子', '', '1', '1407681961', '1407681961', '1');
INSERT INTO `zb_addon_hook` VALUES ('8', 'UploadFile', '上传文件钩子', '', '1', '1407681961', '1407681961', '1');
INSERT INTO `zb_addon_hook` VALUES ('9', 'SendMessage', '发送消息钩子', '', '1', '1407681961', '1407681961', '1');
INSERT INTO `zb_addon_hook` VALUES ('10', 'SyncLogin', '第三方登陆', 'SyncLogin', '1', '1407681961', '1407681961', '1');

-- -----------------------------
-- Table structure for `zb_addon_sync_login`
-- -----------------------------
DROP TABLE IF EXISTS `zb_addon_sync_login`;
CREATE TABLE `zb_addon_sync_login` (
  `id` int(11) unsigned NOT NULL auto_increment COMMENT 'ID',
  `uid` int(11) unsigned NOT NULL COMMENT '用户ID',
  `type` varchar(15) NOT NULL default '' COMMENT '类别',
  `openid` varchar(64) NOT NULL default '' COMMENT 'OpenID',
  `access_token` varchar(64) NOT NULL default '' COMMENT 'AccessToken',
  `refresh_token` varchar(64) NOT NULL default '' COMMENT 'RefreshToken',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '更新时间',
  `sort` int(11) unsigned NOT NULL default '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL default '0' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='第三方登陆插件表';


-- -----------------------------
-- Table structure for `zb_category`
-- -----------------------------
DROP TABLE IF EXISTS `zb_category`;
CREATE TABLE `zb_category` (
  `id` int(11) unsigned NOT NULL auto_increment COMMENT '分类ID',
  `pid` int(11) unsigned NOT NULL default '0' COMMENT '父分类ID',
  `group` tinyint(4) NOT NULL default '0' COMMENT '分组',
  `doc_type` tinyint(4) NOT NULL default '0' COMMENT '分类模型',
  `title` varchar(32) NOT NULL default '' COMMENT '分类名称',
  `url` varchar(127) NOT NULL COMMENT '链接地址',
  `content` text NOT NULL COMMENT '内容',
  `index_template` varchar(32) NOT NULL default '' COMMENT '列表封面模版',
  `detail_template` varchar(32) NOT NULL default '' COMMENT '详情页模版',
  `post_auth` tinyint(4) NOT NULL default '0' COMMENT '投稿权限',
  `icon` varchar(32) NOT NULL default '' COMMENT '缩略图',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '修改时间',
  `sort` tinyint(4) unsigned NOT NULL default '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL default '0' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COMMENT='栏目分类表';

-- -----------------------------
-- Records of `zb_category`
-- -----------------------------
INSERT INTO `zb_category` VALUES ('1', '0', '1', '3', '促销活动', '', '            ', 'index_default', 'detail_default', '1', 'fa fa-send-o', '1431926468', '1446519011', '1', '1');
INSERT INTO `zb_category` VALUES ('9', '0', '1', '1', '会员', 'User/index', '', '', '', '0', 'fa fa-users', '1435894071', '1435895080', '9', '1');
INSERT INTO `zb_category` VALUES ('10', '0', '1', '1', '标签', 'Tag/index', '', '', '', '0', 'fa fa-tags', '1435896603', '1435896603', '11', '0');
INSERT INTO `zb_category` VALUES ('33', '0', '1', '2', '联系我们', '', '联系我们', '', '', '1', '', '1446616328', '1446616328', '0', '1');
INSERT INTO `zb_category` VALUES ('17', '16', '3', '2', '关于我们', '', '', '', '', '0', '', '1435896882', '1435921242', '0', '1');
INSERT INTO `zb_category` VALUES ('18', '16', '3', '2', '联系我们', '', '', '', '', '0', '', '1435896882', '1435896882', '0', '1');
INSERT INTO `zb_category` VALUES ('19', '16', '3', '2', '友情链接', '', '', '', '', '0', '', '1435896882', '1435896882', '0', '1');
INSERT INTO `zb_category` VALUES ('20', '16', '3', '2', '加入我们', '', '', '', '', '0', '', '1435896882', '1435896882', '0', '1');
INSERT INTO `zb_category` VALUES ('34', '0', '1', '2', '服务指南', '', '服务指南', '', '', '1', '', '1446616355', '1446616355', '0', '1');
INSERT INTO `zb_category` VALUES ('22', '21', '3', '2', '用户协议', '', '', '', '', '0', '', '1435922579', '1435922579', '0', '1');
INSERT INTO `zb_category` VALUES ('23', '21', '3', '2', '常见问题', '', '', '', '', '0', '', '1435922602', '1435922602', '0', '1');
INSERT INTO `zb_category` VALUES ('24', '21', '3', '2', '意见反馈', '', '', '', '', '0', '', '1435922628', '1435922628', '0', '1');
INSERT INTO `zb_category` VALUES ('26', '25', '3', '1', 'CoreThink框架', '', '', '', '', '0', '', '1435922823', '1435922823', '0', '1');
INSERT INTO `zb_category` VALUES ('27', '25', '3', '1', '微＋微信平台', '', '', '', '', '0', '', '1435922866', '1435923215', '0', '1');
INSERT INTO `zb_category` VALUES ('35', '0', '1', '2', '加盟合作', '', '加盟合作', '', '', '1', '', '1446616371', '1446616371', '0', '1');
INSERT INTO `zb_category` VALUES ('36', '0', '1', '2', '人才招聘', '', '人才招聘', '', '', '1', '', '1446616380', '1446616380', '0', '1');
INSERT INTO `zb_category` VALUES ('37', '0', '1', '3', '公司公告', '', '            ', '', '', '1', '', '1446977738', '1446977738', '0', '1');
INSERT INTO `zb_category` VALUES ('31', '0', '1', '3', '最新咨询', '', '                        ', '', '', '0', 'fa fa-bank', '1444676736', '1446518998', '0', '1');
INSERT INTO `zb_category` VALUES ('32', '0', '1', '3', '文化活动', '', '                        ', '', '', '1', 'fa fa-bug', '1446519021', '1446519033', '0', '1');

-- -----------------------------
-- Table structure for `zb_document`
-- -----------------------------
DROP TABLE IF EXISTS `zb_document`;
CREATE TABLE `zb_document` (
  `id` int(11) unsigned NOT NULL auto_increment COMMENT '文档ID',
  `cid` int(11) unsigned NOT NULL default '0' COMMENT '分类ID',
  `doc_type` tinyint(3) unsigned NOT NULL default '0' COMMENT '文档类型ID',
  `uid` int(11) unsigned NOT NULL default '0' COMMENT '发布者ID',
  `view` int(11) unsigned NOT NULL default '0' COMMENT '阅读量',
  `comment` int(11) NOT NULL default '0' COMMENT '评论数',
  `good` int(11) unsigned NOT NULL default '0' COMMENT '赞数',
  `bad` int(11) unsigned NOT NULL default '0' COMMENT '踩数',
  `mark` int(11) unsigned NOT NULL default '0' COMMENT '收藏',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '发布时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '更新时间',
  `sort` tinyint(4) unsigned NOT NULL default '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL default '1' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='文档类型基础表';

-- -----------------------------
-- Records of `zb_document`
-- -----------------------------
INSERT INTO `zb_document` VALUES ('1', '31', '3', '1', '3', '0', '0', '0', '0', '1444708800', '1446608504', '0', '1');
INSERT INTO `zb_document` VALUES ('2', '31', '3', '8888', '22', '0', '0', '0', '0', '1446609600', '1446615308', '0', '1');
INSERT INTO `zb_document` VALUES ('3', '31', '3', '8888', '7', '0', '0', '0', '0', '1446609600', '1446615343', '0', '1');
INSERT INTO `zb_document` VALUES ('4', '37', '3', '8888', '5', '0', '0', '0', '0', '1446955200', '1446977767', '0', '1');

-- -----------------------------
-- Table structure for `zb_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `zb_document_article`;
CREATE TABLE `zb_document_article` (
  `id` int(11) unsigned NOT NULL COMMENT '文档ID',
  `title` varchar(127) NOT NULL default '' COMMENT '标题',
  `abstract` varchar(255) NOT NULL default '' COMMENT '简介',
  `content` text NOT NULL COMMENT '正文内容',
  `tags` varchar(127) NOT NULL COMMENT '标签',
  `cover` int(11) NOT NULL default '0' COMMENT '封面图片ID',
  `file` int(11) NOT NULL default '0' COMMENT '附件ID',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文章类型扩展表';

-- -----------------------------
-- Records of `zb_document_article`
-- -----------------------------
INSERT INTO `zb_document_article` VALUES ('1', '网站上线了', '', '        网站上线了    ', '', '2', '0');
INSERT INTO `zb_document_article` VALUES ('2', '长谢伏瞻等陪同下，总理深入洛阳', '', '<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	中秋时节，9月23日至25日，中共中央政治局常委、国务院总理李克强来到了秋阳朗照、硕果累累的中原大地。\r\n</p>\r\n<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	作为曾在河南工作生活七年之久的老书记，李克强总理一直情牵中原热土、心系父老乡亲。他说，我以曾作为河南人民的一员而引以为荣，并将不断从我所体会到的河南人民的宝贵品格中汲取智慧和力量。他坦言，来到河南，我有一种回家的感觉。\r\n</p>\r\n<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	在万家团圆、农事丰收的乙未中秋到来之际，总理“回家”了！\r\n</p>\r\n<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	依然是风尘仆仆、昼夜兼程，在省委书记郭庚茂、省长谢伏瞻等陪同下，总理深入洛阳、许昌、郑州，一路上谈改革、论发展，体民情、察民生，访故地、看变化，总理的脚步，深深印在中原大地；总理的情怀，深深留在人民心中。\r\n</p>\r\n<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	中秋时节，9月23日至25日，中共中央政治局常委、国务院总理李克强来到了秋阳朗照、硕果累累的中原大地。\r\n</p>\r\n<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	作为曾在河南工作生活七年之久的老书记，李克强总理一直情牵中原热土、心系父老乡亲。他说，我以曾作为河南人民的一员而引以为荣，并将不断从我所体会到的河南人民的宝贵品格中汲取智慧和力量。他坦言，来到河南，我有一种回家的感觉。\r\n</p>', '', '3', '0');
INSERT INTO `zb_document_article` VALUES ('3', '中共中央政治局常委、国务院总理李克强来到了', '', '<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	中秋时节，9月23日至25日，中共中央政治局常委、国务院总理李克强来到了秋阳朗照、硕果累累的中原大地。\r\n</p>\r\n<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	作为曾在河南工作生活七年之久的老书记，李克强总理一直情牵中原热土、心系父老乡亲。他说，我以曾作为河南人民的一员而引以为荣，并将不断从我所体会到的河南人民的宝贵品格中汲取智慧和力量。他坦言，来到河南，我有一种回家的感觉。\r\n</p>\r\n<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	在万家团圆、农事丰收的乙未中秋到来之际，总理“回家”了！\r\n</p>\r\n<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	依然是风尘仆仆、昼夜兼程，在省委书记郭庚茂、省长谢伏瞻等陪同下，总理深入洛阳、许昌、郑州，一路上谈改革、论发展，体民情、察民生，访故地、看变化，总理的脚步，深深印在中原大地；总理的情怀，深深留在人民心中。\r\n</p>\r\n<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	中秋时节，9月23日至25日，中共中央政治局常委、国务院总理李克强来到了秋阳朗照、硕果累累的中原大地。\r\n</p>\r\n<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	作为曾在河南工作生活七年之久的老书记，李克强总理一直情牵中原热土、心系父老乡亲。他说，我以曾作为河南人民的一员而引以为荣，并将不断从我所体会到的河南人民的宝贵品格中汲取智慧和力量。他坦言，来到河南，我有一种回家的感觉。\r\n</p>', '', '4', '0');
INSERT INTO `zb_document_article` VALUES ('4', '公司公告', '公司公告', '<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	秋时节，9月23日至25日，中共中央政治局常委、国务院总理李克强来到了秋阳朗照、硕果累累的中原大地。\r\n</p>\r\n<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	作为曾在河南工作生活七年之久的老书记，李克强总理一直情牵中原热土、心系父老乡亲。他说，我以曾作为河南人民的一员而引以为荣，并将不断从我所体会到的河南人民的宝贵品格中汲取智慧和力量。他坦言，来到河南，我有一种回家的感觉。\r\n</p>\r\n<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	在万家团圆、农事丰收的乙未中秋到来之际，总理“回家”了！\r\n</p>\r\n<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	依然是风尘仆仆、昼夜兼程，在省委书记郭庚茂、省长谢伏瞻等陪同下，总理深入洛阳、许昌、郑州，一路上谈改革、论发展，体民情、察民生，访故地、看变化，总理的脚步，深深印在中原大地；总理的情怀，深深留在人民心中。\r\n</p>\r\n<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	中秋时节，9月23日至25日，中共中央政治局常委、国务院总理李克强来到了秋阳朗照、硕果累累的中原大地。\r\n</p>\r\n<p style=\"margin-left:12px;font-size:13px;font-family:微软雅黑, Arial, Helvetica, sans-serif;color:#6F6F6F;\">\r\n	作为曾在河南工作生活七年之久的老书记，李克强总理一直情牵中原热土、心系父老乡亲。他说，我以曾作为河南人民的一员而引以为荣，并将不断从我所\r\n</p>', '', '0', '0');

-- -----------------------------
-- Table structure for `zb_document_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `zb_document_attribute`;
CREATE TABLE `zb_document_attribute` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '' COMMENT '字段名',
  `title` varchar(100) NOT NULL default '' COMMENT '字段标题',
  `field` varchar(100) NOT NULL default '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL default '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL default '' COMMENT '字段默认值',
  `tip` varchar(100) NOT NULL default '' COMMENT '备注',
  `show` tinyint(1) unsigned NOT NULL default '1' COMMENT '是否显示',
  `options` varchar(255) NOT NULL default '' COMMENT '参数',
  `doc_type` tinyint(4) unsigned NOT NULL default '0' COMMENT '文档模型',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL default '0' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='文档属性字段表';

-- -----------------------------
-- Records of `zb_document_attribute`
-- -----------------------------
INSERT INTO `zb_document_attribute` VALUES ('1', 'cid', '分类', 'int(11) unsigned NOT NULL ', 'select', '0', '所属分类', '1', '', '0', '1383891233', '1384508336', '1');
INSERT INTO `zb_document_attribute` VALUES ('2', 'uid', '用户ID', 'int(11) unsigned NOT NULL ', 'num', '0', '用户ID', '0', '', '0', '1383891233', '1384508336', '1');
INSERT INTO `zb_document_attribute` VALUES ('3', 'view', '阅读量', 'varchar(255) NOT NULL', 'num', '0', '标签', '0', '', '0', '1413303715', '1413303715', '1');
INSERT INTO `zb_document_attribute` VALUES ('4', 'comment', '评论数', 'int(11) unsigned NOT NULL ', 'num', '0', '评论数', '0', '', '0', '1383891233', '1383894927', '1');
INSERT INTO `zb_document_attribute` VALUES ('5', 'good', '赞数', 'int(11) unsigned NOT NULL ', 'num', '0', '赞数', '0', '', '0', '1383891233', '1384147827', '1');
INSERT INTO `zb_document_attribute` VALUES ('6', 'bad', '踩数', 'int(11) unsigned NOT NULL ', 'num', '0', '踩数', '0', '', '0', '1407646362', '1407646362', '1');
INSERT INTO `zb_document_attribute` VALUES ('7', 'ctime', '创建时间', 'int(11) unsigned NOT NULL ', 'time', '0', '创建时间', '1', '', '0', '1383891233', '1383895903', '1');
INSERT INTO `zb_document_attribute` VALUES ('8', 'utime', '更新时间', 'int(11) unsigned NOT NULL ', 'time', '0', '更新时间', '0', '', '0', '1383891233', '1384508277', '1');
INSERT INTO `zb_document_attribute` VALUES ('9', 'sort', '排序', 'int(11) unsigned NOT NULL ', 'num', '0', '用于显示的顺序', '1', '', '0', '1383891233', '1383895757', '1');
INSERT INTO `zb_document_attribute` VALUES ('10', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '1', '数据状态', '0', '-1:删除\r\n0:禁用\r\n1:正常', '0', '1383891233', '1384508496', '1');
INSERT INTO `zb_document_attribute` VALUES ('11', 'title', '标题', 'char(127) NOT NULL ', 'text', '', '文档标题', '1', '', '3', '1383891233', '1383894778', '1');
INSERT INTO `zb_document_attribute` VALUES ('12', 'abstract', '简介', 'varchar(255) NOT NULL', 'textarea', '', '文档简介', '1', '', '3', '1383891233', '1384508496', '1');
INSERT INTO `zb_document_attribute` VALUES ('13', 'content', '正文内容', 'text', 'kindeditor', '', '文章正文内容', '1', '', '3', '1383891233', '1384508496', '1');
INSERT INTO `zb_document_attribute` VALUES ('14', 'tags', '文章标签', 'varchar(127) NOT NULL', 'tags', '', '标签', '1', '', '3', '1383891233', '1384508496', '1');
INSERT INTO `zb_document_attribute` VALUES ('15', 'cover', '封面', 'int(11) unsigned NOT NULL ', 'picture', '0', '文档封面', '1', '', '3', '1383891233', '1384508496', '1');
INSERT INTO `zb_document_attribute` VALUES ('16', 'file', '附件', 'int(11) unsigned NOT NULL ', 'file', '0', '附件', '1', '', '3', '1439454552', '1439454552', '1');

-- -----------------------------
-- Table structure for `zb_document_type`
-- -----------------------------
DROP TABLE IF EXISTS `zb_document_type`;
CREATE TABLE `zb_document_type` (
  `id` tinyint(4) unsigned NOT NULL auto_increment COMMENT '模型ID',
  `name` char(16) NOT NULL default '' COMMENT '模型名称',
  `title` char(16) NOT NULL default '' COMMENT '模型标题',
  `icon` varchar(32) NOT NULL default '' COMMENT '缩略图',
  `main_field` int(11) NOT NULL default '0' COMMENT '主要字段',
  `list_field` varchar(127) NOT NULL default '' COMMENT '列表显示字段',
  `field_sort` varchar(255) NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL default '' COMMENT '表单字段分组',
  `system` tinyint(4) unsigned NOT NULL default '0' COMMENT '系统类型',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '修改时间',
  `sort` tinyint(4) unsigned NOT NULL default '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL default '0' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `zb_document_type`
-- -----------------------------
INSERT INTO `zb_document_type` VALUES ('1', 'link', '链接', 'fa fa-link', '0', '', '', '', '1', '1426580628', '1426580628', '0', '1');
INSERT INTO `zb_document_type` VALUES ('2', 'page', '单页', 'fa fa-file-text', '0', '', '', '', '1', '1426580628', '1426580628', '0', '1');
INSERT INTO `zb_document_type` VALUES ('3', 'article', '文章', 'fa fa-file-word-o', '11', '11', '{\"1\":[\"1\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\"],\"2\":[\"9\",\"7\"]}', '1:基础\n2:扩展', '0', '1426580628', '1426580628', '0', '1');

-- -----------------------------
-- Table structure for `zb_jifenchongzhi`
-- -----------------------------
DROP TABLE IF EXISTS `zb_jifenchongzhi`;
CREATE TABLE `zb_jifenchongzhi` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) default NULL COMMENT '商家ID',
  `bank` varchar(255) default NULL COMMENT '汇款银行',
  `mingcheng` varchar(255) default NULL COMMENT ' 汇款名称',
  `money` varchar(255) default NULL COMMENT '汇款金额',
  `banksn` varchar(255) default NULL COMMENT '流水号',
  `tel` varchar(255) default NULL COMMENT '联系电话',
  `email` varchar(255) default NULL COMMENT '联系邮箱',
  `beizhu` text COMMENT '备       注',
  `addtime` int(11) default NULL,
  `status` int(11) default '0' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `zb_jifenchongzhi`
-- -----------------------------
INSERT INTO `zb_jifenchongzhi` VALUES ('1', '8888', '建设银行', '充积分', '1000', 'SN488234', '1331212', '121212@1212.com', '测试备注', '1447478035', '0');
INSERT INTO `zb_jifenchongzhi` VALUES ('2', '8888', '', '', '', '', '', '', '', '1447478480', '0');
INSERT INTO `zb_jifenchongzhi` VALUES ('3', '8888', '啊撒大声地', '爱的', '阿萨德', '阿萨德', '阿萨德', 'asd', '啊撒大声地', '1447478565', '0');
INSERT INTO `zb_jifenchongzhi` VALUES ('4', '3522', '工商银行', '充值积分', '1000', 'SN99898', '13311109315', '99889@qwqwq.com', 'CESHI', '1447489596', '0');
INSERT INTO `zb_jifenchongzhi` VALUES ('5', '8895', '工商那个音', '充值', '1000', 'SN1212', '13', '13', '测试', '1447626255', '0');
INSERT INTO `zb_jifenchongzhi` VALUES ('6', '8900', '工商银行', '预存积分', '1000', 'SN0909', '13311109315', '99889@qwqwq.com', '我存了1000块钱', '1447652582', '0');

-- -----------------------------
-- Table structure for `zb_log`
-- -----------------------------
DROP TABLE IF EXISTS `zb_log`;
CREATE TABLE `zb_log` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) default NULL COMMENT '用户ID',
  `money` int(11) default NULL COMMENT '消费金额',
  `jifen` int(11) default NULL COMMENT '赠送积分数',
  `addtime` int(11) default NULL COMMENT '添加时间',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='积分赠送记录表';

-- -----------------------------
-- Records of `zb_log`
-- -----------------------------
INSERT INTO `zb_log` VALUES ('1', '3522', '', '20', '1447200646');
INSERT INTO `zb_log` VALUES ('2', '8899', '', '300', '1447305654');
INSERT INTO `zb_log` VALUES ('3', '8898', '', '600', '1447305706');
INSERT INTO `zb_log` VALUES ('4', '', '', '0', '1447625111');

-- -----------------------------
-- Table structure for `zb_public_comment`
-- -----------------------------
DROP TABLE IF EXISTS `zb_public_comment`;
CREATE TABLE `zb_public_comment` (
  `id` int(11) unsigned NOT NULL auto_increment COMMENT '评论ID',
  `pid` int(11) unsigned NOT NULL default '0' COMMENT '评论父ID',
  `uid` int(11) unsigned NOT NULL default '0' COMMENT '用户ID',
  `table` int(11) unsigned NOT NULL default '0' COMMENT '数据表ID',
  `group` tinyint(3) unsigned NOT NULL default '0' COMMENT '分组',
  `data_id` int(11) unsigned NOT NULL COMMENT '数据ID',
  `content` text NOT NULL COMMENT '评论内容',
  `pictures` varchar(15) NOT NULL default '' COMMENT '图片列表',
  `rate` tinyint(3) NOT NULL default '0' COMMENT '评价/评分',
  `good` int(11) unsigned NOT NULL default '0' COMMENT '赞数',
  `bad` int(11) unsigned NOT NULL default '0' COMMENT '踩数',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '更新时间',
  `sort` tinyint(4) unsigned NOT NULL default '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL default '0' COMMENT '状态',
  `ip` varchar(15) NOT NULL COMMENT '来源IP',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='评论表';


-- -----------------------------
-- Table structure for `zb_public_digg`
-- -----------------------------
DROP TABLE IF EXISTS `zb_public_digg`;
CREATE TABLE `zb_public_digg` (
  `id` int(11) unsigned NOT NULL auto_increment COMMENT 'ID',
  `table` tinyint(3) unsigned NOT NULL default '0' COMMENT '数据表ID',
  `data_id` int(11) unsigned NOT NULL default '0' COMMENT '数据ID',
  `type` tinyint(3) NOT NULL default '0' COMMENT 'Digg类型',
  `uid` int(11) unsigned NOT NULL default '0' COMMENT '用户ID',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '更新时间',
  `sort` int(11) unsigned NOT NULL default '0' COMMENT '排序',
  `status` int(11) unsigned NOT NULL default '0' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Digg表';


-- -----------------------------
-- Table structure for `zb_public_tag`
-- -----------------------------
DROP TABLE IF EXISTS `zb_public_tag`;
CREATE TABLE `zb_public_tag` (
  `id` int(11) unsigned NOT NULL auto_increment COMMENT 'ID',
  `title` varchar(32) NOT NULL COMMENT '标签',
  `count` int(11) unsigned NOT NULL default '0' COMMENT '数量',
  `group` tinyint(4) unsigned NOT NULL default '0' COMMENT '分组',
  `cover` int(11) unsigned NOT NULL default '0' COMMENT '图标',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '修改时间',
  `sort` int(11) unsigned NOT NULL default '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL default '0' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='标签表';


-- -----------------------------
-- Table structure for `zb_public_upload`
-- -----------------------------
DROP TABLE IF EXISTS `zb_public_upload`;
CREATE TABLE `zb_public_upload` (
  `id` int(11) unsigned NOT NULL auto_increment COMMENT '上传ID',
  `name` varchar(255) NOT NULL default '' COMMENT '文件名',
  `path` varchar(255) NOT NULL default '' COMMENT '文件路径',
  `url` varchar(255) NOT NULL default '' COMMENT '文件链接',
  `ext` char(4) NOT NULL default '' COMMENT '文件类型',
  `size` int(11) unsigned NOT NULL default '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL default '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL default '' COMMENT '文件sha1编码',
  `location` varchar(15) NOT NULL default '' COMMENT '文件存储位置',
  `download` int(11) unsigned NOT NULL default '0' COMMENT '下载次数',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '上传时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '修改时间',
  `sort` int(11) unsigned NOT NULL default '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL default '0' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='文件上传表';

-- -----------------------------
-- Records of `zb_public_upload`
-- -----------------------------
INSERT INTO `zb_public_upload` VALUES ('1', 'logo.jpg', '/Uploads/2015-10-14/561d3f1fc15bf.jpg', '', 'jpg', '29735', 'bc3a2c5071d684f227d2bccfc6015a8c', '717c813d861e52621cd84525aedf5b2e81db30aa', 'Local', '0', '1444757279', '1444757279', '0', '1');
INSERT INTO `zb_public_upload` VALUES ('2', 'start.png', '/Uploads/2015-11-04/5638de0eabd8c.png', '', 'png', '40159', '59a986552472c5bd2e54991fc68a12ba', 'a6862c83b2f4ce36121cc23d5d9a25bfed1f65b2', 'Local', '0', '1446567438', '1446567438', '0', '1');
INSERT INTO `zb_public_upload` VALUES ('3', '17_8804_6040_100_3(1).jpg', '/Uploads/2015-11-04/56399902efea8.jpg', '', 'jpg', '34835', '0c3edeae0745b93088ed0f7232d3e3fa', 'f3ff028af9b31426e812b162ac7c653fefa6b488', 'Local', '0', '1446615298', '1446615298', '0', '1');
INSERT INTO `zb_public_upload` VALUES ('4', '17_8820_6040_100_6(2).jpg', '/Uploads/2015-11-04/5639992e5ec1e.jpg', '', 'jpg', '2926', '34a7c4f9ca65ee469cf755423e63e9fd', '128e04c425d3dfa5e9e4bf8f8cc284e547c288eb', 'Local', '0', '1446615342', '1446615342', '0', '1');

-- -----------------------------
-- Table structure for `zb_system_config`
-- -----------------------------
DROP TABLE IF EXISTS `zb_system_config`;
CREATE TABLE `zb_system_config` (
  `id` int(10) unsigned NOT NULL auto_increment COMMENT '配置ID',
  `title` varchar(32) NOT NULL default '' COMMENT '配置标题',
  `name` varchar(32) NOT NULL COMMENT '配置名称',
  `value` text NOT NULL COMMENT '配置值',
  `group` tinyint(4) unsigned NOT NULL default '0' COMMENT '配置分组',
  `type` varchar(16) NOT NULL default '' COMMENT '配置类型',
  `options` varchar(255) NOT NULL default '' COMMENT '配置额外值',
  `tip` varchar(100) NOT NULL default '' COMMENT '配置说明',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '更新时间',
  `sort` tinyint(4) unsigned NOT NULL default '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL default '0' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='系统配置表';

-- -----------------------------
-- Records of `zb_system_config`
-- -----------------------------
INSERT INTO `zb_system_config` VALUES ('1', '站点开关', 'TOGGLE_WEB_SITE', '1', '1', 'select', '0:关闭,1:开启', '站点关闭后将不能访问', '1378898976', '1406992386', '1', '1');
INSERT INTO `zb_system_config` VALUES ('2', '网站标题', 'WEB_SITE_TITLE', '泽百通管理系统', '1', 'text', '', '网站标题前台显示标题', '1378898976', '1379235274', '2', '1');
INSERT INTO `zb_system_config` VALUES ('3', '网站口号', 'WEB_SITE_SLOGAN', '惠泽百姓  通达天下', '1', 'text', '', '网站口号、宣传标语、一句话介绍', '1434081649', '1434081649', '2', '1');
INSERT INTO `zb_system_config` VALUES ('4', '网站LOGO', 'WEB_SITE_LOGO', '1', '1', 'picture', '', '网站LOGO', '1407003397', '1407004692', '3', '1');
INSERT INTO `zb_system_config` VALUES ('5', '网站描述', 'WEB_SITE_DESCRIPTION', '泽百通商业管理系统', '1', 'textarea', '', '网站搜索引擎描述', '1378898976', '1379235841', '4', '1');
INSERT INTO `zb_system_config` VALUES ('6', '网站关键字', 'WEB_SITE_KEYWORD', '泽百通商业管理系统', '1', 'textarea', '', '网站搜索引擎关键字', '1378898976', '1381390100', '5', '1');
INSERT INTO `zb_system_config` VALUES ('7', '版权信息', 'WEB_SITE_COPYRIGHT', '版权所有 © 2015 泽百通', '1', 'text', '', '设置在网站底部显示的版权信息，如“版权所有 © 2014-2015 科斯克网络科技”', '1406991855', '1406992583', '6', '1');
INSERT INTO `zb_system_config` VALUES ('8', '网站备案号', 'WEB_SITE_ICP', '', '1', 'text', '', '设置在网站底部显示的备案号，如“苏ICP备1502009-2号\"', '1378900335', '1415983236', '7', '1');
INSERT INTO `zb_system_config` VALUES ('9', '站点统计', 'WEB_SITE_STATISTICS', '', '1', 'textarea', '', '支持百度、Google、cnzz等所有Javascript的统计代码', '1407824190', '1407824303', '8', '1');
INSERT INTO `zb_system_config` VALUES ('10', '注册开关', 'TOGGLE_USER_REGISTER', '1', '2', 'select', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1');
INSERT INTO `zb_system_config` VALUES ('11', '允许注册方式', 'ALLOW_REG_TYPE', 'username,email,mobile', '2', 'checkbox', 'username:用户名注册\r\nemail:邮箱注册\r\nmobile:手机注册', '', '0', '0', '2', '1');
INSERT INTO `zb_system_config` VALUES ('12', '注册时间间隔', 'LIMIT_TIME_BY_IP', '0', '2', 'num', '', '同一IP注册时间间隔秒数', '1379228036', '1379228036', '3', '1');
INSERT INTO `zb_system_config` VALUES ('13', '评论开关', 'TOGGLE_USER_COMMENT', '1', '2', 'select', '0:关闭评论,1:允许评论', '评论关闭后用户不能进行评论', '1418715779', '1418716106', '4', '1');
INSERT INTO `zb_system_config` VALUES ('14', '文件上传大小', 'UPLOAD_FILE_SIZE', '10', '2', 'num', '', '文件上传大小单位：MB', '1428681031', '1428681031', '5', '1');
INSERT INTO `zb_system_config` VALUES ('15', '图片上传大小', 'UPLOAD_IMAGE_SIZE', '2', '2', 'num', '', '图片上传大小单位：MB', '1428681071', '1428681071', '6', '1');
INSERT INTO `zb_system_config` VALUES ('16', '敏感字词', 'SENSITIVE_WORDS', '傻逼,垃圾', '2', 'textarea', '', '用户注册及内容显示敏感字词', '1420385145', '1420387079', '7', '1');
INSERT INTO `zb_system_config` VALUES ('17', '后台主题', 'ADMIN_THEME', 'blue', '3', 'select', 'default:默认主题\r\nblue:蓝色理想\r\ngreen:绿色生活', '后台界面主题', '1436678171', '1436690570', '1', '1');
INSERT INTO `zb_system_config` VALUES ('18', 'URL模式', 'URL_MODEL', '2', '3', 'select', '0:普通模式\r\n1:PATHINFO模式\r\n2:REWRITE模式\r\n3:兼容模式', '', '1438423248', '0', '2', '1');
INSERT INTO `zb_system_config` VALUES ('19', '是否显示页面Trace', 'SHOW_PAGE_TRACE', '0', '3', 'select', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '3', '1');
INSERT INTO `zb_system_config` VALUES ('20', '开发模式', 'DEVELOP_MODE', '1', '3', 'select', '1:开启\r\n0:关闭', '开发模式下会显示菜单管理、配置管理、数据字典等开发者工具', '1432393583', '1432393583', '4', '1');
INSERT INTO `zb_system_config` VALUES ('21', '静态资源版本标识', 'STATIC_VERSION', '20150803', '3', 'text', '', '静态资源版本标识可以防止服务器缓存', '1438564784', '1438564784', '5', '1');
INSERT INTO `zb_system_config` VALUES ('22', 'CDN静态资源列表', 'CDN_RESOURCE_LIST', '', '3', 'textarea', '', '配置此项后系统自带的jquery等类库将不会再重复加载', '1438564784', '1438564784', '6', '1');
INSERT INTO `zb_system_config` VALUES ('23', '系统加密KEY', 'AUTH_KEY', 'Ro|wne_giFdt[zcTe)V<g<t}{%DGU$X-kL/}-v%+B`_mXAf-$<gEH{brJt\\\"z\\\"~Zp', '3', 'textarea', '', '轻易不要修改此项，否则容易造成用户无法登录；如要修改，务必备份原key', '1438647773', '1438647815', '7', '1');
INSERT INTO `zb_system_config` VALUES ('24', '配置分组', 'CONFIG_GROUP_LIST', '1:基本\r\n2:用户\r\n3:系统\r\n', '3', 'array', '', '配置分组', '1379228036', '1426930700', '8', '1');
INSERT INTO `zb_system_config` VALUES ('25', '分页数量', 'ADMIN_PAGE_ROWS', '10', '3', 'num', '', '分页时每页的记录数', '1434019462', '1434019481', '9', '1');
INSERT INTO `zb_system_config` VALUES ('26', '栏目分组', 'CATEGORY_GROUP_LIST', '1:默认\r\n3:导航\r\n', '3', 'array', '', '栏目分类分组', '1433602137', '1433602165', '10', '1');

-- -----------------------------
-- Table structure for `zb_system_menu`
-- -----------------------------
DROP TABLE IF EXISTS `zb_system_menu`;
CREATE TABLE `zb_system_menu` (
  `id` int(11) unsigned NOT NULL auto_increment COMMENT '菜单ID',
  `pid` int(11) unsigned NOT NULL default '0' COMMENT '上级菜单ID',
  `title` varchar(32) NOT NULL default '' COMMENT '菜单名称',
  `url` varchar(127) NOT NULL default '' COMMENT '链接地址',
  `icon` varchar(64) NOT NULL COMMENT '图标',
  `dev` tinyint(4) unsigned NOT NULL default '0' COMMENT '是否开发模式可见',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '修改时间',
  `sort` tinyint(4) unsigned NOT NULL default '0' COMMENT '排序（同级有效）',
  `status` tinyint(4) NOT NULL default '0' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=108 DEFAULT CHARSET=utf8 COMMENT='后台菜单表';

-- -----------------------------
-- Records of `zb_system_menu`
-- -----------------------------
INSERT INTO `zb_system_menu` VALUES ('1', '0', '首页', 'Admin/Index/index', 'fa fa-home', '0', '1426580628', '1438276217', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('2', '0', '系统', 'Admin/SystemConfig/group', 'fa fa-cog', '0', '1426580628', '1438276235', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('3', '0', '内容', 'Admin/Category/index', 'fa fa-tasks', '0', '1430290092', '1438276260', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('4', '0', '用户', 'Admin/User/index', 'fa fa-users', '0', '1426580628', '1438276990', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('5', '0', '其它', 'Admin/Other/index', 'fa fa-cloud', '0', '1426580628', '1444761168', '4', '0');
INSERT INTO `zb_system_menu` VALUES ('6', '1', '系统操作', '', 'fa fa-folder-open-o', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('7', '2', '系统功能', '', 'fa fa-folder-open-o', '0', '1426580628', '1438277612', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('8', '2', '扩展中心', '', 'fa fa-folder-open-o', '0', '1437185077', '1437185164', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('9', '2', '数据中心', '', 'fa fa-folder-open-o', '0', '1426580628', '1426580628', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('10', '3', '内容管理', '', 'fa fa-folder-open-o', '0', '1430290276', '1438277591', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('11', '3', '文件管理', '', 'fa fa-folder-open-o', '0', '1430290276', '1438277393', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('12', '4', '用户管理', '', 'fa fa-folder-open-o', '0', '1426580628', '1438277454', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('13', '6', '清空缓存', 'Admin/Index/rmdirr', '', '0', '1427475588', '1427475588', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('14', '7', '系统设置', 'Admin/SystemConfig/group', 'fa fa-gears', '0', '1426580628', '1438276516', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('15', '14', '修改设置', 'Admin/SystemConfig/groupSave', '', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('16', '7', '文档模型', 'Admin/DocumentType/index', 'fa fa-th-list', '1', '1426580628', '1438277140', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('17', '16', '添加', 'Admin/DocumentType/add', '', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('18', '16', '编辑', 'Admin/DocumentType/edit', '', '0', '1426580628', '1426580628', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('19', '16', '设置状态', 'Admin/DocumentType/setStatus', '', '0', '1426580628', '1426580628', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('20', '16', '字段管理', 'Admin/DocumentAttribute/index', '', '0', '1426580628', '1430291065', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('21', '20', '添加', 'Admin/DocumentAttribute/add', '', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('22', '20', '编辑', 'Admin/DocumentAttribute/edit', '', '0', '1426580628', '1426580628', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('23', '20', '设置状态', 'Admin/DocumentAttribute/setStatus', '', '0', '1426580628', '1426580628', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('24', '7', '菜单管理', 'Admin/SystemMenu/index', 'fa fa-bars', '1', '1426580628', '1438276552', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('25', '24', '添加', 'Admin/SystemMenu/add', '', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('26', '24', '编辑', 'Admin/SystemMenu/edit', '', '0', '1426580628', '1426580628', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('27', '24', '设置状态', 'Admin/SystemMenu/setStatus', '', '0', '1426580628', '1426580628', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('28', '7', '配置管理', 'Admin/SystemConfig/index', 'fa fa-cogs', '1', '1426580628', '1438276571', '4', '1');
INSERT INTO `zb_system_menu` VALUES ('29', '28', '添加', 'Admin/SystemConfig/add', '', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('30', '28', '编辑', 'Admin/SystemConfig/edit', '', '0', '1426580628', '1426580628', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('31', '28', '设置状态', 'Admin/SystemConfig/setStatus', '', '0', '1426580628', '1426580628', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('32', '8', '功能模块', 'Admin/SystemModule/index', 'fa fa-th-large', '0', '1437185242', '1438276915', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('33', '32', '安装', 'Admin/SystemModule/install', '', '0', '1427475588', '1427475588', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('34', '32', '卸载', 'Admin/SystemModule/uninstall', '', '0', '1427475588', '1427475588', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('35', '32', '更新信息', 'Admin/SystemModule/updateInfo', '', '0', '1427475588', '1427475588', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('36', '32', '设置状态', 'Admin/SystemModule/setStatus', '', '0', '1427475588', '1427475588', '4', '1');
INSERT INTO `zb_system_menu` VALUES ('37', '8', '前台主题', 'Admin/SystemTheme/index', 'fa fa-adjust', '0', '1437185290', '1438277065', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('38', '37', '安装', 'Admin/SystemTheme/install', '', '0', '1427475588', '1427475588', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('39', '37', '卸载', 'Admin/SystemTheme/uninstall', '', '0', '1427475588', '1427475588', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('40', '37', '更新信息', 'Admin/SystemTheme/updateInfo', '', '0', '1427475588', '1427475588', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('41', '37', '设置状态', 'Admin/SystemTheme/setStatus', '', '0', '1427475588', '1427475588', '4', '1');
INSERT INTO `zb_system_menu` VALUES ('42', '37', '切换主题', 'Admin/SystemTheme/setCurrent', '', '0', '1427475588', '1427475588', '5', '1');
INSERT INTO `zb_system_menu` VALUES ('43', '8', '系统插件', 'Admin/Addon/index', 'fa fa-th', '0', '1427475588', '1438277115', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('44', '43', '安装', 'Admin/Addon/install', '', '0', '1427475588', '1427475588', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('45', '43', '卸载', 'Admin/Addon/uninstall', '', '0', '1427475588', '1427475588', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('46', '43', '执行', 'Admin/Addon/execute', '', '0', '1427475588', '1427475588', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('47', '43', '插件设置', 'Admin/Addon/config', '', '0', '1427475588', '1427475588', '4', '1');
INSERT INTO `zb_system_menu` VALUES ('48', '43', '插件后台管理', 'Admin/Addon/adminList', '', '0', '1427475588', '1427475588', '5', '1');
INSERT INTO `zb_system_menu` VALUES ('49', '48', '新增数据', 'Admin/Addon/adminAdd', '', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('50', '48', '编辑数据', 'Admin/Addon/adminEdit', '', '0', '1426580628', '1426580628', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('51', '48', '设置状态', 'Admin/Addon/setStatus', '', '0', '1426580628', '1426580628', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('52', '9', '数据字典', 'Admin/Datebase/index', 'fa fa-database', '1', '1429851071', '1438276624', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('53', '9', '数据备份', 'Admin/Datebase/export', 'fa fa-copy', '0', '1426580628', '1426580628', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('54', '53', '备份', 'Admin/Datebase/do_export', '', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('55', '53', '优化表', 'Admin/Datebase/optimize', '', '0', '1426580628', '1426580628', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('56', '53', '修复表', 'Admin/Datebase/repair', '', '0', '1426580628', '1426580628', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('57', '9', '数据还原', 'Admin/Datebase/import', 'fa fa-refresh', '1', '1426580628', '1438276890', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('58', '57', '还原备份', 'Admin/Datebase/do_import', '', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('59', '57', '删除备份', 'Admin/Datebase/del', '', '0', '1426580628', '1426580628', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('60', '10', '栏目分类', 'Admin/Category/index', 'fa fa-th-list', '0', '1426580628', '1438277233', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('61', '60', '添加', 'Admin/Category/add', '', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('62', '60', '编辑', 'Admin/Category/edit', '', '0', '1426580628', '1426580628', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('63', '60', '设置状态', 'Admin/Category/setStatus', '', '0', '1426580628', '1426580628', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('64', '60', '文档列表', 'Admin/Document/index', '', '0', '1427475588', '1427475588', '4', '1');
INSERT INTO `zb_system_menu` VALUES ('65', '64', '添加', 'Admin/Document/add', '', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('66', '64', '编辑', 'Admin/Document/edit', '', '0', '1426580628', '1426580628', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('67', '64', '移动', 'Admin/Document/move', '', '0', '1426580628', '1426580628', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('68', '64', '设置状态', 'Admin/Document/setStatus', '', '0', '1426580628', '1426580628', '4', '1');
INSERT INTO `zb_system_menu` VALUES ('69', '10', '标签列表', 'Admin/PublicTag/index', 'fa fa-tags', '0', '1426580628', '1438277250', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('70', '69', '添加', 'Admin/PublicTag/add', '', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('71', '69', '编辑', 'Admin/PublicTag/edit', '', '0', '1426580628', '1426580628', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('72', '69', '设置状态', 'Admin/PublicTag/setStatus', '', '0', '1426580628', '1426580628', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('73', '69', '搜索标签(自动完成)', 'Admin/PublicTag/searchTags', '', '0', '1426580628', '1426580628', '4', '1');
INSERT INTO `zb_system_menu` VALUES ('74', '10', '万能评论', 'Admin/PublicComment/index', 'fa fa-comments', '0', '1426580628', '1438277284', '4', '1');
INSERT INTO `zb_system_menu` VALUES ('75', '74', '添加', 'Admin/PublicComment/add', '', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('76', '74', '编辑', 'Admin/PublicComment/edit', '', '0', '1426580628', '1426580628', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('77', '74', '设置状态', 'Admin/PublicComment/setStatus', '', '0', '1426580628', '1426580628', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('78', '10', '回收站', 'Admin/Document/recycle', 'fa fa-trash', '0', '1427475588', '1438277313', '5', '1');
INSERT INTO `zb_system_menu` VALUES ('79', '11', '上传管理', 'Admin/PublicUpload/index', 'fa fa-upload', '0', '1427475588', '1438277518', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('80', '79', '上传文件', 'Admin/PublicUpload/upload', '', '0', '1427475588', '1427475588', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('81', '79', '删除文件', 'Admin/PublicUpload/delete', '', '0', '1427475588', '1427475588', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('82', '79', '设置状态', 'Admin/PublicUpload/setStatus', '', '0', '1426580628', '1426580628', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('83', '79', '下载图片', 'Admin/PublicUpload/downremoteimg', '', '0', '1427475588', '1427475588', '4', '1');
INSERT INTO `zb_system_menu` VALUES ('84', '79', '文件浏览', 'Admin/PublicUpload/fileManager', '', '0', '1427475588', '1427475588', '5', '1');
INSERT INTO `zb_system_menu` VALUES ('85', '12', '用户列表', 'Admin/User/index', 'fa fa-user', '0', '1426580628', '1438277505', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('86', '85', '添加', 'Admin/User/add', '', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('87', '85', '编辑', 'Admin/User/edit', '', '0', '1426580628', '1426580628', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('88', '85', '设置状态', 'Admin/User/setStatus', '', '0', '1426580628', '1426580628', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('89', '12', '部门管理', 'Admin/UserGroup/index', 'fa fa-sitemap', '0', '1426580628', '1438277438', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('90', '89', '添加', 'Admin/UserGroup/add', '', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('91', '89', '编辑', 'Admin/UserGroup/edit', '', '0', '1426580628', '1426580628', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('92', '89', '设置状态', 'Admin/UserGroup/setStatus', '', '0', '1426580628', '1426580628', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('93', '12', '消息列表', 'Admin/UserMessage/index', 'fa fa-envelope-o', '0', '1440050363', '1440050363', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('94', '93', '添加', 'Admin/UserMessage/add', '', '0', '1426580628', '1426580628', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('95', '93', '编辑', 'Admin/UserMessage/edit', '', '0', '1426580628', '1426580628', '2', '1');
INSERT INTO `zb_system_menu` VALUES ('96', '93', '设置状态', 'Admin/UserMessage/setStatus', '', '0', '1426580628', '1426580628', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('97', '0', '省市县代理机构', 'Admin/Provincial/index', 'fa fa-group', '0', '1444761122', '1444761220', '3', '1');
INSERT INTO `zb_system_menu` VALUES ('98', '97', '省市管理', '', 'fa fa-folder-open-o', '0', '1444761367', '1444761367', '0', '1');
INSERT INTO `zb_system_menu` VALUES ('99', '103', '添加', '', '', '0', '1444761486', '1444762019', '0', '1');
INSERT INTO `zb_system_menu` VALUES ('100', '103', '编辑', '', '', '0', '1444761500', '1444762030', '0', '1');
INSERT INTO `zb_system_menu` VALUES ('101', '98', '会员列表', '', '', '0', '1444761515', '1444762067', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('102', '101', '编辑', '', '', '0', '1444761538', '1444761538', '0', '1');
INSERT INTO `zb_system_menu` VALUES ('103', '98', '省市区列表', '', '', '0', '1444761999', '1444761999', '0', '1');
INSERT INTO `zb_system_menu` VALUES ('104', '85', '商家列表', 'Admin/User/index', '', '0', '1447626529', '1447626640', '1', '1');
INSERT INTO `zb_system_menu` VALUES ('105', '0', '积分充值', 'Admin/Log/index', 'fa fa-gift', '0', '1447627488', '1447627599', '0', '1');
INSERT INTO `zb_system_menu` VALUES ('106', '105', '积分充值', '', 'fa fa-folder-open-o', '0', '1447652651', '1447652820', '0', '1');
INSERT INTO `zb_system_menu` VALUES ('107', '106', '充值列表', 'Admin/Log/index', 'fa fa-bars', '0', '1447652839', '1447653214', '0', '1');

-- -----------------------------
-- Table structure for `zb_system_module`
-- -----------------------------
DROP TABLE IF EXISTS `zb_system_module`;
CREATE TABLE `zb_system_module` (
  `id` int(11) unsigned NOT NULL auto_increment COMMENT 'ID',
  `name` varchar(32) NOT NULL default '' COMMENT '名称',
  `title` varchar(64) NOT NULL default '' COMMENT '标题',
  `description` varchar(127) NOT NULL default '' COMMENT '描述',
  `developer` varchar(32) NOT NULL default '' COMMENT '开发者',
  `version` varchar(8) NOT NULL default '' COMMENT '版本',
  `admin_menu` text NOT NULL COMMENT '菜单节点',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '更新时间',
  `sort` int(11) unsigned NOT NULL default '0' COMMENT '排序',
  `status` tinyint(3) NOT NULL default '0' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='模块功能表';


-- -----------------------------
-- Table structure for `zb_system_theme`
-- -----------------------------
DROP TABLE IF EXISTS `zb_system_theme`;
CREATE TABLE `zb_system_theme` (
  `id` int(11) unsigned NOT NULL auto_increment COMMENT 'ID',
  `name` varchar(32) NOT NULL default '' COMMENT '名称',
  `title` varchar(64) NOT NULL default '' COMMENT '标题',
  `description` varchar(127) NOT NULL default '' COMMENT '描述',
  `developer` varchar(32) NOT NULL default '' COMMENT '开发者',
  `version` varchar(8) NOT NULL default '' COMMENT '版本',
  `config` text NOT NULL COMMENT '主题配置',
  `current` tinyint(1) unsigned NOT NULL default '0' COMMENT '是否当前主题',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '更新时间',
  `sort` int(11) unsigned NOT NULL default '0' COMMENT '排序',
  `status` tinyint(3) NOT NULL default '0' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='前台主题表';

-- -----------------------------
-- Records of `zb_system_theme`
-- -----------------------------
INSERT INTO `zb_system_theme` VALUES ('1', 'default', '默认主题', 'CoreThink默认主题', '南京科斯克网络科技有限公司', '1.0', '', '1', '1437786501', '1444757034', '0', '1');

-- -----------------------------
-- Table structure for `zb_user_group`
-- -----------------------------
DROP TABLE IF EXISTS `zb_user_group`;
CREATE TABLE `zb_user_group` (
  `id` int(11) unsigned NOT NULL auto_increment COMMENT '部门ID',
  `pid` int(11) unsigned NOT NULL default '0' COMMENT '上级部门ID',
  `title` varchar(32) NOT NULL default '' COMMENT '部门名称',
  `icon` varchar(32) NOT NULL COMMENT '图标',
  `menu_auth` text COMMENT '菜单权限',
  `category_auth` text COMMENT '栏目分类权限',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '修改时间',
  `sort` tinyint(4) unsigned NOT NULL default '0' COMMENT '排序（同级有效）',
  `status` tinyint(4) NOT NULL default '0' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='部门信息表';

-- -----------------------------
-- Records of `zb_user_group`
-- -----------------------------
INSERT INTO `zb_user_group` VALUES ('1', '0', '管理员', '', '', '', '1426881003', '1427552428', '0', '1');
INSERT INTO `zb_user_group` VALUES ('2', '0', '省级管理员', '', '7,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,3,10,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,11,79,80,81,82,83,84', '', '1446483598', '1446483598', '0', '1');
INSERT INTO `zb_user_group` VALUES ('3', '2', '市级管理员', '', '3,10,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,11,79,80,81,82,83,84', '', '1446483626', '1446483626', '0', '1');
INSERT INTO `zb_user_group` VALUES ('4', '3', '县级管理员', '', '3,10,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,11,79,80,81,82,83,84', '', '1446483650', '1446483657', '0', '1');
INSERT INTO `zb_user_group` VALUES ('5', '0', '财务', '', '1,6,13', '', '1446484754', '1446484754', '0', '1');

-- -----------------------------
-- Table structure for `zb_user_message`
-- -----------------------------
DROP TABLE IF EXISTS `zb_user_message`;
CREATE TABLE `zb_user_message` (
  `id` int(10) NOT NULL auto_increment COMMENT '消息ID',
  `pid` int(11) unsigned NOT NULL default '0' COMMENT '消息父ID',
  `title` varchar(1024) NOT NULL default '' COMMENT '消息标题',
  `content` text COMMENT '消息内容',
  `type` tinyint(4) unsigned NOT NULL default '0' COMMENT '0系统消息,1评论消息,2私信消息',
  `to_uid` int(11) unsigned NOT NULL default '0' COMMENT '接收用户ID',
  `from_uid` int(10) unsigned NOT NULL default '0' COMMENT '私信消息发信用户ID',
  `is_read` tinyint(4) unsigned NOT NULL default '0' COMMENT '是否已读',
  `ctime` int(11) unsigned NOT NULL default '0' COMMENT '发送时间',
  `utime` int(11) unsigned NOT NULL default '0' COMMENT '更新时间',
  `sort` tinyint(4) unsigned NOT NULL default '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL default '1' COMMENT '状态',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户消息表';


-- -----------------------------
-- Table structure for `zb_xiaofei`
-- -----------------------------
DROP TABLE IF EXISTS `zb_xiaofei`;
;

-- -----------------------------
-- Records of `zb_xiaofei`
-- -----------------------------
INSERT INTO `zb_xiaofei` VALUES ('3522', '', '20', '1447200646', '五家渠市', '1', 'F659004', '3522');
INSERT INTO `zb_xiaofei` VALUES ('8899', '', '300', '1447305654', '李四', '2', 'S47304991', '8899');
INSERT INTO `zb_xiaofei` VALUES ('8898', '', '600', '1447305706', '张三', '3', 'S46953382', '8898');
